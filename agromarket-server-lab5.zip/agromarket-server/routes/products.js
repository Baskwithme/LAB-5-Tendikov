import { Router } from 'express';
import { products } from '../data/products.js';

const router = Router();

// GET /api/products и поиск по названию
router.get('/', (req, res) => {
  const search = String(req.query.search || '').toLowerCase();
  const result = products.filter((p) =>
    String(p.name ?? p.title ?? '').toLowerCase().includes(search)
  );
  res.json(result);
});

// GET /api/products/:id
router.get('/:id', (req, res) => {
  const product = products.find((p) => String(p.id) === req.params.id);

  if (!product) {
    return res.status(404).json({ error: 'Товар не найден' });
  }

  res.json(product);
});

export default router;
